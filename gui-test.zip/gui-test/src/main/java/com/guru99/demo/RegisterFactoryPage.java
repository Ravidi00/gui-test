package com.guru99.demo;

import net.bytebuddy.asm.Advice;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import utils.TestApp;

public class RegisterFactoryPage {
    @FindBy(name = "firstName")
    private WebElement firstNameWebElement;

    @FindBy(name = "lastName")
    private WebElement lastNameWebElement;

    @FindBy(name = "phone")
    private WebElement phoneWebElement;

    @FindBy(name = "userName")
    private WebElement emailWebElement;

    @FindBy(name = "country")
    private WebElement countryWebElement;

    @FindBy(name = "email")
    private WebElement userNameWebElement;

    @FindBy(name = "password")
    private WebElement passwordWebElement;

    @FindBy(name = "confirmPassword")
    private  WebElement confirmPasswordWebElement;

    @FindBy(name = "submit")
    private WebElement submitButtonWebElement;

    public RegisterFactoryPage setFirstName(String firstName){
        firstNameWebElement.sendKeys(firstName);
        return this;
    }
    public RegisterFactoryPage setLastName(String lastName){
        lastNameWebElement.sendKeys(lastName);
        return this;
    }
    public RegisterFactoryPage setPhone(String phone){
        phoneWebElement.sendKeys(phone);
        return this;
    }
    public RegisterFactoryPage setEmail(String email){
        emailWebElement.sendKeys(email);
        return this;
    }
    public RegisterFactoryPage selectCountry(String countryName){
        Select countryDropDown = new Select(countryWebElement);
        countryDropDown.selectByVisibleText(countryName);
        return this;
    }
    public RegisterFactoryPage setUserName(String userName){
        userNameWebElement.sendKeys(userName);
        return this;
    }

    public RegisterFactoryPage setPassword(String password) {
        passwordWebElement.sendKeys(password);
        return this;
    }
    public RegisterFactoryPage setConfirmPassword(String confirmPassword) {
        confirmPasswordWebElement.sendKeys(confirmPassword);
        return this;
    }
    public RegisterSuccessFactoryPage submit() {
       RegisterPage x = new RegisterPage();
        x.handleUnexpectedPopup();
        submitButtonWebElement.click();
        return PageFactory.initElements(TestApp.getInstance().getDriver(),RegisterSuccessFactoryPage.class);
    }

}
