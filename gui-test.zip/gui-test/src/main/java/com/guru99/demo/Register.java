package com.guru99.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Register {

    public void setFirstName(WebDriver driver, String firstName){
        waitUntilNextElementAppears(driver,By.name("firstName"), 5);
        WebElement firstNameElement = driver.findElement(By.name("firstName"));
        firstNameElement.sendKeys(firstName);
    }

    public void SetLastName(WebDriver driver, String lastName){
        waitUntilNextElementAppears(driver,By.name("lastName"), 5);
        WebElement lastNameElement = driver.findElement(By.name("lastName"));
        lastNameElement.sendKeys(lastName);
    }

    public void setPhone(WebDriver driver, String PhoneNo){
        waitUntilNextElementAppears(driver,By.name("phone"), 5);
        WebElement phoneElement = driver.findElement(By.name("phone"));
        phoneElement.sendKeys(PhoneNo);
    }
    public void setEmail(WebDriver driver,String userName){
        waitUntilNextElementAppears(driver,By.name("userName"), 5);
        WebElement emailElement = driver.findElement(By.id("userName"));
        emailElement.sendKeys(userName);
    }
    public void selectCountry(WebDriver driver, String countryName){
        waitUntilNextElementAppears(driver,By.name("country"), 5);
        Select countryDropDownElement = new Select(driver.findElement(By.name( "country")));
        countryDropDownElement.selectByVisibleText(countryName);
    }
    public void setUserName(WebDriver driver, String userName){
        waitUntilNextElementAppears(driver,By.id("email"), 5);
        WebElement emailElement = driver.findElement(By.id("email"));
        emailElement.sendKeys(userName);
    }
    public void setPassword(WebDriver driver,String password){
        waitUntilNextElementAppears(driver,By.name("password"), 5);
        WebElement passwordElement = driver.findElement(By.name("password"));
        passwordElement.sendKeys(password);
    }
    public void setConfirmPassword(WebDriver driver, String password){
        waitUntilNextElementAppears(driver,By.name("confirmPassword"), 5);
        WebElement confirmPasswordElement = driver.findElement(By.name("confirmPassword"));
        confirmPasswordElement.sendKeys(password);
    }
    public void submit(WebDriver driver){
        waitUntilNextElementAppears(driver,By.name("submit"), 5);
        WebElement submitButtonElement = driver.findElement(By.name("submit"));
        submitButtonElement.click();
    }

    private WebElement waitUntilNextElementAppears(WebDriver driver,By locator, int maxTimeOut){
        WebElement element = new WebDriverWait(driver, Duration.ofSeconds(maxTimeOut)).until(
                ExpectedConditions.presenceOfElementLocated(locator)
        );
        return element;
    }

}
