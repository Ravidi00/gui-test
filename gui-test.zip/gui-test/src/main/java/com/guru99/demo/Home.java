package com.guru99.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Home {

    public void clickOnRegisterMenu(WebDriver driver){
        WebElement registerMenuElement = driver.findElement(By.linkText("REGISTER"));
        registerMenuElement.click();
    }
}
