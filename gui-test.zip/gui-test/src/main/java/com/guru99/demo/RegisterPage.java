package com.guru99.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.PropertyFileReader;
import utils.TestApp;

import java.time.Duration;

public class RegisterPage {
    WebDriver driver = TestApp.getInstance().getDriver();
    PropertyFileReader prop = new PropertyFileReader();
    String firstNameWebElement = prop.getProperty( "RegisterPage" , "first.name.element");
    String lastNameWebElement = prop.getProperty( "RegisterPage" , "last.name.element");
    String phoneWebElement = prop.getProperty( "RegisterPage", "phone.element");
    String emailWebElement = prop.getProperty( "RegisterPage" , "email.element");
    String countryWebElement = prop.getProperty( "RegisterPage" , "country.element");
    String userNameWebElement =prop.getProperty( "RegisterPage" , "user.name.element");
    String passwordWebElement = prop.getProperty( "RegisterPage" , "password.element");
    String confirmPasswordWebElement = prop.getProperty( "RegisterPage", "confirm.password.element");
    String submitWebElement = prop.getProperty( "RegisterPage" , "submit.button.element");


    public  RegisterPage setFirstName(String firstName){
        TestApp.getInstance().waitUntilNextElementAppears(By.name(firstNameWebElement), 10);
        WebElement firstNameElement = driver.findElement(By.name(firstNameWebElement));
        firstNameElement.sendKeys(firstName);
        return this;
    }

    public RegisterPage SetLastName(String lastName){
        TestApp.getInstance().waitUntilNextElementAppears(By.name(lastNameWebElement), 10);
        WebElement lastNameElement = driver.findElement(By.name(lastNameWebElement));
        lastNameElement.sendKeys(lastName);
        return this;
    }

    public RegisterPage setPhone(String PhoneNo){
        TestApp.getInstance().waitUntilNextElementAppears(By.name(phoneWebElement), 5);
        WebElement phoneElement = driver.findElement(By.name(phoneWebElement));
        phoneElement.sendKeys(PhoneNo);
        return this;
    }
    public RegisterPage setEmail(String userName){
        TestApp.getInstance().waitUntilNextElementAppears(By.name(emailWebElement), 5);
        WebElement emailElement = driver.findElement(By.id(emailWebElement));
        emailElement.sendKeys(userName);
        return this;
    }
    public RegisterPage selectCountry(String countryName){
        TestApp.getInstance().waitUntilNextElementAppears(By.name(countryWebElement), 5);
        Select countryDropDownElement = new Select(driver.findElement(By.name( countryWebElement)));
        countryDropDownElement.selectByVisibleText(countryName);
        return this;
    }
    public RegisterPage setUserName(String userName){
        TestApp.getInstance().waitUntilNextElementAppears(By.id(userNameWebElement), 5);
        WebElement emailElement = driver.findElement(By.id(userNameWebElement));
        emailElement.sendKeys(userName);
        return this;
    }
    public RegisterPage setPassword(String password){
        TestApp.getInstance().waitUntilNextElementAppears(By.name(passwordWebElement), 5);
        WebElement passwordElement = driver.findElement(By.name(passwordWebElement));
        passwordElement.sendKeys(password);
        return this;
    }
    public RegisterPage setConfirmPassword(String password){
        TestApp.getInstance().waitUntilNextElementAppears(By.name(confirmPasswordWebElement), 5);
        WebElement confirmPasswordElement = driver.findElement(By.name(confirmPasswordWebElement));
        confirmPasswordElement.sendKeys(password);
        return this;
    }
    public RegisterSuccessPage submit(){
        TestApp.getInstance().waitUntilNextElementAppears(By.name(submitWebElement), 5);
        WebElement submitButtonElement = driver.findElement(By.name(submitWebElement));
        handleUnexpectedPopup();
        submitButtonElement.click();
        return new RegisterSuccessPage();
    }

    public void handleUnexpectedPopup() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
            WebElement closeBtn = wait.until(
                    ExpectedConditions.elementToBeClickable(By.className("cb-close"))
            );
            closeBtn.click();
            System.out.println("Popup closed successfully");
        } catch (TimeoutException e) {
            System.out.println("No popup appeared");
        } catch (Exception e) {
            System.out.println("Popup handling failed: " + e.getMessage());
        }
    }


}
