import io.cucumber.java.PendingException;
import io.cucumber.java.en.Given;

public class MyStepdefs {
    @Given("User is on Home Page --> Register Page")
    public void setUp() {

    }
}
