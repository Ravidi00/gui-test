package com.guru99.demo;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utils.TestApp;

public class RegisterUserStepDef {
    HomeFactoryPage homePage;
    RegisterFactoryPage registerPage;
    RegisterSuccessFactoryPage registerSucessPage;

    @Given("User is on Home Page --> Register Page")
    public void setUp() {
        TestApp.getInstance().openBrowser();
        TestApp.getInstance().navigateToURL();
        homePage = PageFactory.initElements(TestApp.getInstance().getDriver(),HomeFactoryPage.class);
        registerPage = homePage.clickOnRegisterMenu();

    }

    @Given("User enter first name as {string}")
    public void setFirstName(String firstName) {
        registerPage.setFirstName(firstName);
    }

    @And("User enter last name as {string}")
    public void setLastName(String lastName) {
        registerPage.setLastName(lastName);
    }

    @And("User enter phone number as {string}")
    public void setPhone(String phoneNo) {
        registerPage.setPhone(phoneNo);
    }

    @And("User enter email address as {string}")
    public void setEmail(String email) {
        registerPage.setEmail(email);
    }

    @And("user select country as {string}")
    public void SelectCountry(String countryName) {
        registerPage.selectCountry(countryName);
    }

    @And("User enter user name as {string}")
    public void setUserName(String userName) {
        registerPage.setUserName(userName);
    }

    @And("User enter password as {string}")
    public void setPassword(String password) {
        registerPage.setPassword(password);
    }

    @And("User enter confirm password as {string}")
    public void setConfirmPassword(String confirmPassword) {
        registerPage.setConfirmPassword(confirmPassword);
    }

    @When("User clicks on submit button")
    public void submit() {
      registerSucessPage = registerPage.submit();
    }

    @Then("Salutation message will display {string}")
    public void getMessage(String expectedMessage) {
        Assert.assertEquals(
                registerSucessPage.getSalutatioinMessage(),
                expectedMessage,
                "Failed to Create New User:"
        );
    }
}
