package com.guru99.demo;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import utils.TestApp;

public class RegisterUserTest3 {
    HomePage homePage;
    RegisterPage registerPage;
    RegisterSuccessPage registerSuccessPage;

    @BeforeMethod
    public void setUp() {
        TestApp.getInstance().openBrowser();
        TestApp.getInstance().navigateToURL();
        homePage = new HomePage();
        homePage.clickOnRegisterMenu();
        registerPage = new RegisterPage();
        registerSuccessPage = new RegisterSuccessPage();
    }

    @Test
    public void testRegisterNewUser() {
        registerPage.setFirstName("Aruni");
        registerPage.SetLastName("Perera");
        registerPage.setPhone("0777888954");
        registerPage.setEmail("aruni@gmail.com");
        registerPage.selectCountry( "SRI LANKA");
        registerPage.setUserName("Arunip");
        registerPage.setPassword("Aruni@123");
        registerPage.setConfirmPassword("Aruni@123");
        registerPage.submit();
        Assert.assertEquals(
                registerSuccessPage.getSalutationMessage(),
                "Dear Aruni Perera," ,
                "Failed to Register New User:"
        );
    }

}

