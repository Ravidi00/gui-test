package com.guru99.demo;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import utils.TestApp;

public class RegisterUserTest5 {

    HomeFactoryPage homePage;
    RegisterFactoryPage registerPage;
    RegisterSuccessFactoryPage registerSucessPage;

    @BeforeMethod
    public void setUp() {
        TestApp.getInstance().openBrowser();
        TestApp.getInstance().navigateToURL();
        homePage = PageFactory.initElements(TestApp.getInstance().getDriver(),HomeFactoryPage.class);
        registerPage = homePage.clickOnRegisterMenu();
    }

    @Test
    public void testRegisterNumber() {
        registerSucessPage = registerPage
                .setFirstName("Aruni")
                .setLastName("Perera")
                .setPhone("0777444555")
                .setEmail("aruni@gmail.com")
                .selectCountry("SRI LANKA")
                .setUserName("AruniP")
                .setPassword("Aruni@123")
                .setConfirmPassword("Aruni@123")
                .submit();
        Assert.assertEquals(
                registerSucessPage.getSalutatioinMessage(),
                 "Dear Aruni Perera," , "Failed to create new user"
        );
    }

}
