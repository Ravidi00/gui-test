package com.guru99.demo;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import utils.TestApp;

public class RegisterUserTest4 {
    HomePage home;
    RegisterPage register;
    RegisterSuccessPage regSuccess;

    @BeforeMethod
    public void setUp() {
        TestApp.getInstance().openBrowser();
        TestApp.getInstance().navigateToURL();
        home = new HomePage();
        register = home.clickOnRegisterMenu();

    }


    @Test
    public void testRegisterNewUser() {
        regSuccess = register
                .setFirstName("Aruni")
                .SetLastName("Perera")
                .setPhone("0777455071")
                .setEmail("aruni@gmail.com")
                .selectCountry("SRI LANKA")
                .setUserName("AruniP")
                .setPassword("Aruni@123")
                .setConfirmPassword("Aruni@123")
                .submit();
        Assert.assertEquals(
                regSuccess.getSalutationMessage(),
                 "Dear Aruni Perera," ,
                "Failed to create New User:"
        );

    }
}
