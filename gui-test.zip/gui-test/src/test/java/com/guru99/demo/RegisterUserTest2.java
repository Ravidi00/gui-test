package com.guru99.demo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import utils.PropertyFileReader;

public class RegisterUserTest2 {

    WebDriver driver;
    PropertyFileReader prop = new PropertyFileReader();
    String baseURL = prop.getProperty( "config", "url");
    Home home;
    Register register;
    RegisterSuccess registerSuccess;

    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        driver.get(baseURL);
        driver.manage().window().maximize();
        home = new Home();
        home.clickOnRegisterMenu(driver);
        register = new Register();
        registerSuccess = new RegisterSuccess();
    }

    @Test
    public void testRegisterNewUser() {
        register.setFirstName(driver,"Aruni");
        register.SetLastName(driver, "Perera");
        register.setPhone(driver, "0771122334");
        register.setEmail(driver, "aruniperera@gmail.com");
        register.selectCountry(driver, "SWEDEN");
        register.setUserName(driver, "AruniP");
        register.setPassword(driver, "Aruni@123");
        register.setConfirmPassword(driver,"Aruni@123");
        register.submit(driver);
        String message = registerSuccess.getSalutationMessage(driver);
        Assert.assertEquals(message, "Dear Aruni Perera,", "Failed:");
    }
}
