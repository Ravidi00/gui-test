package com.guru99.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import utils.PropertyFileReader;

import java.time.Duration;
import java.util.List;

public class RegisterUserTest1 {
    WebDriver driver;
    PropertyFileReader prop = new PropertyFileReader();
    String baseURL = prop.getProperty( "config", "url");

    @Test
    public void testRegisterNewUser() throws InterruptedException {

        driver = new ChromeDriver();
        driver.get(baseURL);
        driver.manage().window().maximize();


        // WebElement registerMenuElement = driver.findElement(By.xpath( "//*[text()=\"REGISTER\"]"));
        WebElement registerMenuElement = driver.findElement(By.linkText("REGISTER"));
        registerMenuElement.click();

        // List<WebElement> registerElement = driver.findElements(By.xpath( "//*[@href=\"register.php\"]"));
        //registerElement.get(0).click();

        //driver.findElement(By.linkText("REGISTER")).click();
        waitUntilNextElementAppears(By.name("firstName"), 30);
        WebElement firstNameElement = driver.findElement(By.name("firstName"));
        firstNameElement.sendKeys("Aruni");

        WebElement lastNameElement = driver.findElement(By.name("lastName"));
        lastNameElement.sendKeys("Perera");

        WebElement phoneElement = driver.findElement(By.name("phone"));
        phoneElement.sendKeys("0774577667");

        Select countryDropDownElement = new Select(driver.findElement(By.name( "country")));
        countryDropDownElement.selectByVisibleText("SRI LANKA");
        Thread.sleep(1500);
        countryDropDownElement.selectByValue("SWITZERLAND");
        Thread.sleep(1500);
        countryDropDownElement.selectByIndex(8);


        WebElement emailElement = driver.findElement(By.id("userName"));
        emailElement.sendKeys("aruniperera@gmail.com");

        WebElement userName = driver.findElement(By.id("email"));
        userName.sendKeys("aruniperera@gmail.com");

        WebElement passwordElement = driver.findElement(By.name("password"));
        passwordElement.sendKeys("Aruni@123");

        WebElement confirmPasswordElement = driver.findElement(By.name("confirmPassword"));
        confirmPasswordElement.sendKeys("Aruni@123");

        WebElement submitButtonElement = driver.findElement(By.name("submit"));
        submitButtonElement.click();

        waitUntilNextElementAppears(By.xpath("//*[contains(text(),\"Dear \")]"), 10);

        String actualValue = driver.findElement(By.xpath("//*[contains(text(),\"Dear \")]")).getText();

        Assert.assertEquals(actualValue, "Dear Aruni Perera,", "Faile to create New User");
    }

    private WebElement waitUntilNextElementAppears(By locator, int maxTimeOut){
        WebElement element = new WebDriverWait(driver, Duration.ofSeconds(maxTimeOut)).until(
                ExpectedConditions.presenceOfElementLocated(locator)
        );
        return element;
    }

}