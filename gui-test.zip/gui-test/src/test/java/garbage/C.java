package garbage;

public class C {
    public void c(){
        System.out.println("c");
    }
    public C cC(){
        System.out.println("cC");
        return this;
    }
    public D cD(){
        System.out.println("cD");
        return new D();
    }
}
