package garbage;

import org.testng.annotations.Test;

public class D {
    @Test
    public void test1() {
        A x = new A();
        x.aA();
        x.aB();
        B y = new B();
        y.bB();
        y.bC();
        C z = new C();
        z.cC();
        z.cD();
    }
    B y;
    C z;
    @Test
    public void test2() {
        A x = new A();
        y = x.aA().aB();
        y.bB().bC();
        z = y.bB().bC();
        x.aA().aB().bB().bC().cC().cD();
    }
}
