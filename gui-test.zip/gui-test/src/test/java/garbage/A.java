package garbage;

public class A {
    public void a(){
        System.out.println("a");
    }
    //Same class return object
    public A aA(){
        System.out.println("aA");
        return this;
    }
    //Separate class return object
    public B aB(){
        System.out.println("aB");
        return new B();
    }
}
